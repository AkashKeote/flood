Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
osmium2shape by Geofabrik, https://geofabrik.de


Please read the OSM wiki how to use shape files.

  https://wiki.openstreetmap.org/wiki/Shapefiles


This shape file was created on: Wed 16 Jul 09:11:58 UTC 2025
GPS rectangle coordinates (lng,lat): 72.74,18.922 x 73.026,19.315
Script URL: https://extract.bbbike.org/?sw_lng=72.74&sw_lat=18.922&ne_lng=73.026&ne_lat=19.315&format=shp.zip&coords=72.784%2C18.922%7C72.886%2C18.94%7C72.969%2C19.073%7C73.026%2C19.203%7C72.978%2C19.257%7C72.963%2C19.292%7C72.815%2C19.315%7C72.74%2C19.262&city=mumbai&lang=en
Name of area: mumbai


We appreciate any feedback, suggestions and a donation!
You can support us via PayPal or bank wire transfer.

  https://extract.bbbike.org/community.html

You can donate any free amount you want. We are happy for every donation,
for 5, 10, 20, or 50 Euro. Whatever you think the service is worth for you,
or you can afford. We need to raise 20 Euro (25 USD) by the end of the day or
600 Euro (700 USD) per month to cover the server costs.
Your donation helps to pay for hosting the service. Many thanks!

thanks, Wolfram Schneider

--
BBBike professional plans: https://extract.bbbike.org/support.html
Planet.osm extracts: https://extract.bbbike.org
BBBike Map Compare: https://mc.bbbike.org
